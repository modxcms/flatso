# Flatso

Get up and running with a standard MODX Blog install with the least barrier to entry. A simple personal blog theme for MODX, done without any "Parent Extras" like "Articles", but instead using MODX 2.4 dependencies to install Extras.