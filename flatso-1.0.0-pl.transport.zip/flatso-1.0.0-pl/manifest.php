<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => '# Flatso

Get up and running with a standard MODX Blog install with the least barrier to entry. A simple personal blog theme for MODX, done without any "Parent Extras" like "Articles", but instead using MODX 2.4 dependencies to install Extras.',
    'changelog' => '# Flatso 1.0.0
- Basic Blog with 2.4 Dependencies and System Config settings`',
    'setup-options' => 'flatso-1.0.0-pl/setup-options.php',
    'requires' => 
    array (
      'mxt' => '>=1.0.0',
      'collections' => '>=3.2.0',
      'tagger' => '>=1.7.0',
      'getresources' => '>=1.6.0',
      'archivist' => '>=1.2.0',
      'getpage' => '>=1.2.0',
      'pthumb' => '>=2.3.0',
      'resizer' => '>=1.0.0',
      'switch' => '>=1.1.0',
      'clientconfig' => '>=1.3.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'afc3ff63abd1fd5fe115e6fbec3f3289',
      'native_key' => 'flatso',
      'filename' => 'modNamespace/8f690521946e243972ff403e8ff3cd1a.vehicle',
      'namespace' => 'flatso',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '06f376ac3a2a5800323d05d3194799af',
      'native_key' => 'flatso.archive_id',
      'filename' => 'modSystemSetting/841cbd3c8c5ff656f93dc247c3c73ca9.vehicle',
      'namespace' => 'flatso',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7cc874781cac2b88979e74e067f29732',
      'native_key' => 'flatso.blog_id',
      'filename' => 'modSystemSetting/e4b3bc5496aeab9d54e30dbf63124382.vehicle',
      'namespace' => 'flatso',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed966a618ebe87fb1ddb6c7e30d99684',
      'native_key' => 'flatso.category_id',
      'filename' => 'modSystemSetting/9a8ab1bb05f33a66315db90f7cde9bb3.vehicle',
      'namespace' => 'flatso',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '85b4e249b971e2a39918e53078a89bb8',
      'native_key' => 'flatso.site_logo',
      'filename' => 'modSystemSetting/5bfddb29e409bbbb3b0b38201af148a1.vehicle',
      'namespace' => 'flatso',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '597c8ba3da6956cdee1b499c739fe8f4',
      'native_key' => NULL,
      'filename' => 'modCategory/cca662eb209ecaee25648e32db306516.vehicle',
      'namespace' => 'flatso',
    ),
  ),
);