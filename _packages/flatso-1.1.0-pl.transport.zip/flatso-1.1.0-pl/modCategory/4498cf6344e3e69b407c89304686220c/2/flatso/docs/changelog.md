# Flatso 1.1.0
- Official Standalone style guide
- Third Config style
- Site name in Config
- Styles for Forms and Tables

# Flatso 1.0.0
- Basic Blog with 2.4 Dependencies and System Config settings
