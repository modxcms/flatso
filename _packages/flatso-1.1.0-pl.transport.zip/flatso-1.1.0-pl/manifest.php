<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2015 MODX Systems, LLC (hello@modx.com) 

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.',
    'readme' => '# Flatso

Get up and running with a standard MODX Blog install with the least barrier to entry. A simple personal blog theme for MODX, done without any "Parent Extras" like "Articles", but instead using MODX 2.4 dependencies to install Extras.

## Installation
 - Turn on `friendly_urls`',
    'changelog' => '# Flatso 1.1.0
- Official Standalone style guide
- Third Config style
- Site name in Config
- Styles for Forms and Tables

# Flatso 1.0.0
- Basic Blog with 2.4 Dependencies and System Config settings
',
    'setup-options' => 'flatso-1.1.0-pl/setup-options.php',
    'requires' => 
    array (
      'mxt' => '>=1.0.0',
      'collections' => '>=3.2.0',
      'tagger' => '>=1.7.0',
      'getresources' => '>=1.6.0',
      'archivist' => '>=1.2.0',
      'getpage' => '>=1.2.0',
      'pthumb' => '>=2.3.0',
      'resizer' => '>=1.0.0',
      'switch' => '>=1.1.0',
      'clientconfig' => '>=1.3.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '841b5740bd194e481053f5f96c1cf194',
      'native_key' => 'flatso',
      'filename' => 'modNamespace/272833e9e44c836cea9458a99030aa2e.vehicle',
      'namespace' => 'flatso',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd32d471fe8fa900dbf6a003db24b266f',
      'native_key' => 'flatso.archive_id',
      'filename' => 'modSystemSetting/c37de845b63e3cd4202d31b5040bc1f6.vehicle',
      'namespace' => 'flatso',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91486a1ab79b4782c943a1277dc46bfd',
      'native_key' => 'flatso.blog_id',
      'filename' => 'modSystemSetting/bab8d8bfb03ef05f19df573e56e3feeb.vehicle',
      'namespace' => 'flatso',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '98154ba9c44095cdc002c15a44c10434',
      'native_key' => 'flatso.category_id',
      'filename' => 'modSystemSetting/aeab94b40b22f87da7c0e65755e8b180.vehicle',
      'namespace' => 'flatso',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '005b0242d3efc03e41b59942af1f13ea',
      'native_key' => 'flatso.site_logo',
      'filename' => 'modSystemSetting/f535224f717de16f4cb0508fd3c48cb6.vehicle',
      'namespace' => 'flatso',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '3339c7196eec07a24bb791d8a67b4a41',
      'native_key' => NULL,
      'filename' => 'modCategory/4498cf6344e3e69b407c89304686220c.vehicle',
      'namespace' => 'flatso',
    ),
  ),
);