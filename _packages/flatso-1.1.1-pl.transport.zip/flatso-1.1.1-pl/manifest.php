<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2015 MODX Systems, LLC (hello@modx.com) 

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.',
    'readme' => '# Flatso

Get up and running with a standard MODX Blog install with the least barrier to entry. A simple personal blog theme for MODX, done without any "Parent Extras" like "Articles", but instead using MODX 2.4 dependencies to install Extras.

## Installation
 - Turn on `friendly_urls`',
    'changelog' => '# Flatso 1.1.1
- Blog ID on RSS pull
- RSS ID Setting and non static RSS Link
- Strip "-" in Category Name caused by tagger output

# Flatso 1.1.0
- Official Standalone style guide
- Third Config style
- Site name in Config
- Styles for Forms and Tables

# Flatso 1.0.0
- Basic Blog with 2.4 Dependencies and System Config settings
',
    'setup-options' => 'flatso-1.1.1-pl/setup-options.php',
    'requires' => 
    array (
      'mxt' => '>=1.0.0',
      'collections' => '>=3.2.0',
      'tagger' => '>=1.7.0',
      'getresources' => '>=1.6.0',
      'archivist' => '>=1.2.0',
      'getpage' => '>=1.2.0',
      'pthumb' => '>=2.3.0',
      'resizer' => '>=1.0.0',
      'switch' => '>=1.1.0',
      'clientconfig' => '>=1.3.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '2997ebb4ef375f5c93a003054bed225d',
      'native_key' => 'flatso',
      'filename' => 'modNamespace/4250a46df01df2b3a99e32d723003902.vehicle',
      'namespace' => 'flatso',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '204c2d44212e2ab0e6be288d2f3097c2',
      'native_key' => 'flatso.archive_id',
      'filename' => 'modSystemSetting/9c72900141febd8faf77c9df7b1e3c43.vehicle',
      'namespace' => 'flatso',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c615537da3f5a013b3880a78a982ad95',
      'native_key' => 'flatso.blog_id',
      'filename' => 'modSystemSetting/345c82cfa674e398efcbba2de49de222.vehicle',
      'namespace' => 'flatso',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0eab9797e2a07cbe4be59aef3d20465d',
      'native_key' => 'flatso.category_id',
      'filename' => 'modSystemSetting/94c7166ebc41b75e54f30fdcc5788e94.vehicle',
      'namespace' => 'flatso',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1682e9fc1dc0f1294cb371beaae5841d',
      'native_key' => 'flatso.rss_id',
      'filename' => 'modSystemSetting/cda0e0d8b2b310bf634aabcef51e4a2d.vehicle',
      'namespace' => 'flatso',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '29ead000d0092b7764d9c3b04760fc9f',
      'native_key' => 'flatso.site_logo',
      'filename' => 'modSystemSetting/badb0a572a2e1fba4acbd54033df3f1e.vehicle',
      'namespace' => 'flatso',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '7fcabcc84aca055bec57e1325253e98a',
      'native_key' => NULL,
      'filename' => 'modCategory/f6b181c8eb09ee4e3799ae557865abb4.vehicle',
      'namespace' => 'flatso',
    ),
  ),
);