<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2015 MODX Systems, LLC (hello@modx.com) 

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.',
    'readme' => '# Flatso

Get up and running with a standard MODX Blog install with the least barrier to entry. A simple personal blog theme for MODX, done without any "Parent Extras" like "Articles", but instead using MODX 2.4 dependencies to install Extras.

## Installation
 - Turn on `friendly_urls`',
    'changelog' => '# Flatso 1.0.0
- Basic Blog with 2.4 Dependencies and System Config settings`',
    'setup-options' => 'flatso-1.0.0-pl/setup-options.php',
    'requires' => 
    array (
      'mxt' => '>=1.0.0',
      'collections' => '>=3.2.0',
      'tagger' => '>=1.7.0',
      'getresources' => '>=1.6.0',
      'archivist' => '>=1.2.0',
      'getpage' => '>=1.2.0',
      'pthumb' => '>=2.3.0',
      'resizer' => '>=1.0.0',
      'switch' => '>=1.1.0',
      'clientconfig' => '>=1.3.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '369c32b80819e397c145f215ea1eb379',
      'native_key' => 'flatso',
      'filename' => 'modNamespace/c73ac834ba04f919a223472e5fd4bfd0.vehicle',
      'namespace' => 'flatso',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a2354c07b3c58387f25303ac9c2db8d3',
      'native_key' => 'flatso.archive_id',
      'filename' => 'modSystemSetting/61717d7a54428da5a3547bbcc03b0657.vehicle',
      'namespace' => 'flatso',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e8eba191d09362e850da15984b1cd65',
      'native_key' => 'flatso.blog_id',
      'filename' => 'modSystemSetting/c1128ed4940bcd42303d8e0d44602b9d.vehicle',
      'namespace' => 'flatso',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '857e3f3488488c0a4be13d452d30c267',
      'native_key' => 'flatso.category_id',
      'filename' => 'modSystemSetting/7efca9b26c36bc92977d8340bd6905f1.vehicle',
      'namespace' => 'flatso',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6a1837a4964e15d1b6f9b9097abdcf4a',
      'native_key' => 'flatso.site_logo',
      'filename' => 'modSystemSetting/1c8287d22c5ad20affefc0ac73199316.vehicle',
      'namespace' => 'flatso',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'b5ae4924d89e285d91374ca377e815bd',
      'native_key' => NULL,
      'filename' => 'modCategory/f5baa71fab7e152d8752d008b33a5f3e.vehicle',
      'namespace' => 'flatso',
    ),
  ),
);