<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2015 MODX Systems, LLC (hello@modx.com) 

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.',
    'readme' => '# Flatso

Get up and running with a standard MODX Blog install with the least barrier to entry. A simple personal blog theme for MODX, done without any "Parent Extras" like "Articles", but instead using MODX 2.4 dependencies to install Extras.

## Installation
 - Turn on `friendly_urls`',
    'changelog' => '# Flatso 1.0.0
- Basic Blog with 2.4 Dependencies and System Config settings',
    'setup-options' => 'flatso-1.0.0-pl/setup-options.php',
    'requires' => 
    array (
      'mxt' => '>=1.0.0',
      'collections' => '>=3.2.0',
      'tagger' => '>=1.7.0',
      'getresources' => '>=1.6.0',
      'archivist' => '>=1.2.0',
      'getpage' => '>=1.2.0',
      'pthumb' => '>=2.3.0',
      'resizer' => '>=1.0.0',
      'switch' => '>=1.1.0',
      'clientconfig' => '>=1.3.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '5ea66e3483f1251f2bcdef019ac8079f',
      'native_key' => 'flatso',
      'filename' => 'modNamespace/c990125812683a86d11964d3acef9315.vehicle',
      'namespace' => 'flatso',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '160af9be0c97b1710a88ef6bd130284e',
      'native_key' => 'flatso.archive_id',
      'filename' => 'modSystemSetting/d8c99106c504c7819b8b73efed19a069.vehicle',
      'namespace' => 'flatso',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '819f322a266fdbf25f7810e54e1fec0b',
      'native_key' => 'flatso.blog_id',
      'filename' => 'modSystemSetting/b137b6259e6042792a0fafbadf41eee2.vehicle',
      'namespace' => 'flatso',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46db3217bcb57335c66582cdc37d3a96',
      'native_key' => 'flatso.category_id',
      'filename' => 'modSystemSetting/d34528179de638588002b06f90894bf8.vehicle',
      'namespace' => 'flatso',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0d7f11ea1299928896c572b072b4b751',
      'native_key' => 'flatso.site_logo',
      'filename' => 'modSystemSetting/b650abf79c9200118afea357a996964f.vehicle',
      'namespace' => 'flatso',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'd57407dbe6c8dd801506c61e400e913f',
      'native_key' => NULL,
      'filename' => 'modCategory/51be37860a796cee9e9ecc5e74be47bf.vehicle',
      'namespace' => 'flatso',
    ),
  ),
);