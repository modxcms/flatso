# Flatso 1.0.0
- Basic Blog with 2.4 Dependencies and System Config settings